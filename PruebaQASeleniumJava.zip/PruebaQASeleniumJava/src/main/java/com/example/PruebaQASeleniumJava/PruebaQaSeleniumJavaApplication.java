package com.example.PruebaQASeleniumJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaQaSeleniumJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaQaSeleniumJavaApplication.class, args);
	}

}
